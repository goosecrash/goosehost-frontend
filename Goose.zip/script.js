const server = ''

async function signUp(user, pass) {
  const req = await fetch(server, {
    method: 'POST', 
    body: JSON.stringify({user, pass})
  })

  req.json().then(res => {console.log(res.status)})
}